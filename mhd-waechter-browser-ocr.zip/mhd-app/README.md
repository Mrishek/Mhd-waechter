# MHD Wächter – Browser/PWA mit echter Kamera-OCR

Die App erkennt ein fotografiertes Mindesthaltbarkeitsdatum (MHD) automatisch mit Tesseract.js und trägt es in das Datumsfeld ein.

## Start
1. Die Dateien auf einen HTTPS-Webserver laden (z. B. GitHub Pages, Netlify oder Vercel).
2. Die Seite auf Android in Chrome öffnen.
3. Kamerazugriff erlauben.
4. „📷 MHD scannen“ drücken.
5. Den Datumsaufdruck groß, gerade und gut beleuchtet aufnehmen.
6. Die App liest den Text per OCR und erkennt Formate wie `24.10.2026`, `24/10/2026`, `2026-10-24` sowie Monat/Jahr.
7. Das erkannte Datum wird vor dem Speichern angezeigt und kann korrigiert werden.

## Wichtig
Die OCR-Bibliothek wird über jsDelivr geladen. Beim ersten Scan ist daher eine Internetverbindung nötig. Danach werden Tesseract-Ressourcen vom Browser zwischengespeichert; die PWA selbst bleibt offline nutzbar. Die Erkennung ist bewusst mit Bestätigung ausgelegt, weil Verpackungsaufdrucke je nach Schrift, Reflexion und Qualität nicht immer zuverlässig lesbar sind.

## Sicherheit/Datenschutz
Das Kamerabild wird von der App nicht an einen eigenen Server gesendet. Die OCR läuft im Browser. Die Tesseract-Bibliothek und Sprachdaten werden allerdings von jsDelivr geladen.
