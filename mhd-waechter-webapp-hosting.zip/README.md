# MHD Wächter – kostenlose Web-App

Diese Version ist für HTTPS-Hosting (z. B. GitHub Pages oder Cloudflare Pages) vorbereitet.
Die Kamera funktioniert im Browser zuverlässig, wenn die App über HTTPS geöffnet wird.

## GitHub Pages
1. Neues öffentliches GitHub-Repository erstellen.
2. Alle Dateien dieses Ordners hochladen, insbesondere `index.html`.
3. Repository → Settings → Pages → Veröffentlichung aus `main` / Root aktivieren.
4. Die erzeugte `github.io`-Adresse öffnen.
GitHub Pages liefert `github.io`-Seiten über HTTPS.

## Cloudflare Pages
Projekt mit GitHub verbinden und als statische Website deployen. Als Output-Verzeichnis den Projektordner verwenden; es wird kein Build-Schritt benötigt.

## Kamera
Beim ersten Scan in Chrome „Zulassen“ wählen.
